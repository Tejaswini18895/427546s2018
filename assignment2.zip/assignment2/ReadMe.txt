--------------------------------------------------------------------
Author Name : Tejaswini Gaddam
Programming Assignment 2
--------------------------------------------------------------------

Files Included: 
1.asgnt2.html
2.circlee.html
3.fract1.html
4.layout.css
5.style.css

-- asgnt1.html is the home page which contains buttons on clikcing directs to approprite pages.

-- On clicking "Drawing wheel" it goes to circlee.html page and pops up 2 text boxes to enter the RADIUS of the wheel and SCORE of that person, on clicking submit button the wheel is dispalyed on the canvas.

-- For the fractals, it redirects to fract1.html page where we need to enter the number of iterations and select the ratio in which you want the line to be divided. Clicking the submit button and for each iteration clicking on the canvas it displays the changes occured to the line.


Extra credit points:

I have used colouring for the wheel, and fractals i have created a list for the selection of the ratio to be divided. I have also created Clear canvas button.  

REFERENCES:
1.https://www.w3schools.com/html/
2.http://stackoverflow.com/
  