--------------------------------------------------------------------
Author Name : Tejaswini Gaddam
Programming Assignment 1: 2D- Primitives
--------------------------------------------------------------------

Files Included: 
1.asgnt1.html
2.circle.html
3.ellipse.html
4.linedraw.html
5.polygon.html
6.rectangle.css
7.polyline.html
8.style.css
9.Output.mp4
10.Readme.txt

-- asgnt1.html is the home page which contains buttons on clikcing directs to approprite pages.

-- All the primitives are drawn without any API funciton and used only mid point algorithm for drawing.

-- Each time user clicks the canvas, a particular point is generated and used for drawing different shapes. This concept is developed using canvas.addEventListener.

-- For the circle,ellipse and polygon the point clicked on canvas is used as the center of the primitive.

-- For line, the start point is generated when the mouse is clicked and when dragged and released the point is taken as the end point.

-- For polyline, each time user clicks the point on canvas the point is considered as start or end point of the line and line is drawn continuously.

-- For rectangle, fist time the user clicks on canvas is taken as start point and when dragged and released the point is considered as fourth co-ordinate and rectangle is drawn.

Extra credit points:

Apart from the regular method, i have used the rubberbanding method like we can drag like, increase decrease or change the shape, direction when drawing the primitives.

I have also attached the ouput.mp4 file for you reference.  


REFERENCES:
1.https://www.w3schools.com/html/
2.http://stackoverflow.com/
  